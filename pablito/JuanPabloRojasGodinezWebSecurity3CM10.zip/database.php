<?php

define('hostname', 'localhost');
define('username', 'root');
define('password', '');
define('database', 'usuarios');


?>